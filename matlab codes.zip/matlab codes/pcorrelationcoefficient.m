clc;
P = imread('cameraman.tif');
% P = imread('D:\dissertation\matlab implementation\project 3\C4.tiff');
x1 = double(P(:,1:end-1));
y1 = double(P(:,2:end));
randIndex1 = randperm(numel(x1));
randIndex1 = randIndex1(1:3000);
x = x1(randIndex1);
y = y1(randIndex1);
h = corrcoef(x,y)
subplot(1,3,1);
scatter(x,y,'.')
xlabel('Pixel gray value on location (x,y)','fontsize',18)
ylabel('Pixel gray value on location (x,y+1)','fontsize',18)
box on

x2 = double(P(1:end-1,:));
y2 = double(P(2:end,:));
randIndex1 = randperm(numel(x2));
randIndex1 = randIndex1(1:3000);
p = x2(randIndex1);
q = y2(randIndex1);
v = corrcoef(p,q)
subplot(1,3,2);
scatter(p,q,'.')
xlabel('Pixel gray value on location (x,y)','fontsize',18)
ylabel('Pixel gray value on location (x+1,y)','fontsize',18)
box on

x3 = double(P(1:end-1,1:end-1));
y3 = double(P(2:end,2:end));
randIndex1 = randperm(numel(x3));
randIndex1 = randIndex1(1:3000);
s = x3(randIndex1);
t = y3(randIndex1);
d = corrcoef(s,t)
subplot(1,3,3);
scatter(s,t,'.')
xlabel('Pixel gray value on location (x,y)','fontsize',18)
ylabel('Pixel gray value on location (x+1,y+1)','fontsize',18)
box on
