%% Reading of image

clc;
clear;
close all;
img = imread('D:\dissertation\misc\4.1.05.tiff');
img = rgb2gray(img);
[m,n] = size(img);

imwrite(img,'cipher1.tiff');
subplot(1,3,1);
imshow(img);
title('original image');

%% Generation of key

Opta = struct('Method','SHA-256','hex','array');
imhx = DataHash(img,Opta);

j = 1;
for h = 1:2:64
    s(j) = hex2dec(imhx(h:h+1));
    j = j+1;
end

%% Generation of chaotic sequence

%sequence is chaotic where 3.57 < r < 4.
r = 3.9+((mod((s(13)+s(14)+s(15)+s(16)+s(17)+s(18)+s(19)+s(20)+s(21)+s(22)+s(23)+s(24)),256)/(2^9))*0.1)+10^(-15); % r parameter for chaotic regime
size = m*n; % size of chaotic array
x(1) = 0.2+((mod((s(1)+s(2)+s(3)+s(4)+s(5)+s(6)+s(7)+s(8)+s(9)+s(10)+s(11)+s(12)),256)/(2^9))*0.1); % initial value
for i = 2:size
   x(i) = r*x(i-1)*(1-x(i-1));
end

%% Sorting of chaotic sequence

[Y,I] = sort(x);

%% Reverse diffusion of image

for j = 25:32
    t(j) = mod(s(j),256);
end

v = de2bi(t,8,'left-msb');
l = v(:,1);
w = l';
u = bi2de(w,'left-msb');

C = imread('D:\dissertation\matlab implementation\comparision 1-d\encryption\logistic_house.tiff');

subplot(1,3,2);
imshow(C); 
title('encrypted image');

c = reshape(C,1,[]);
d(1) = bitxor(c(1),u);
for i = 2:size
    d(i) = bitxor(c(i),c(i-1));
end
P = reshape(d,m,n);

%% Reverse permutation of image

Bperm = reshape(P,1,[]);
B(I) = Bperm;
imgd = reshape(B,m,n);
 
imwrite(imgd,'cipher2.tiff');
imwrite(imgd,'kd1dlogistic_house.tiff');
subplot(1,3,3);
imshow(imgd);
title('decrypted image');

%% Calculation of npcr and uaci

C1 = imread('D:\dissertation\matlab implementation\comparision 1-d\key sensitivity decryption\cipher1.tiff');
C2 = imread('D:\dissertation\matlab implementation\comparision 1-d\key sensitivity decryption\cipher2.tiff');

C1 = double(C1);
C2 = double(C2);

sigma1 = 0;
sigma2 = 0;

for y = 1:m
    for z = 1:n
        
        sigma1 = sigma1+(abs(C1(y,z)-C2(y,z)));
        
         if(C1(y,z)==C2(y,z))
            D(y,z) = 0;
        else
            D(y,z) = 1;
         end
        
       sigma2 = sigma2+D(y,z); 
       
    end
end

uaci = (sigma1*100)/(255*size)
npcr = (sigma2*100)/(size)

