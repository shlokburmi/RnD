%% Reading of image

clc;
clear;
close all;
img1 = imread('D:\dissertation\misc\4.2.03.tiff');
img1 = rgb2gray(img1);
[m,n] = size(img1);

%% Changing of one pixel
 
for f = 1:50
    
img2 = imread('D:\dissertation\misc\4.2.03.tiff');
img2 = rgb2gray(img2);

randindex = randperm(numel(img1));
img2(randindex(2)) = img1(randindex(1));
  
%% Generation of key

Opta = struct('Method','SHA-256','hex','array');
imhxo = DataHash(img1,Opta);

jo = 1;
for ho = 1:2:64
    so(jo) = hex2dec(imhxo(ho:ho+1));
    jo = jo+1;
end

Opta = struct('Method','SHA-256','hex','array');
imhxc = DataHash(img2,Opta);

jc = 1;
for hc = 1:2:64
    sc(jc) = hex2dec(imhxc(hc:hc+1));
    jc = jc+1;
end

%% Generation of chaotic sequence

%sequence is chaotic where 3.57 < r < 4.
ro = 3.9+((mod((so(13)+so(14)+so(15)+so(16)+so(17)+so(18)+so(19)+so(20)+so(21)+so(22)+so(23)+so(24)),256)/(2^9))*0.1); % r parameter for chaotic regime
size = m*n; % size of chaotic array
xo(1) = 0.2+((mod((so(1)+so(2)+so(3)+so(4)+so(5)+so(6)+so(7)+so(8)+so(9)+so(10)+so(11)+so(12)),256)/(2^9))*0.1); % initial value
for io = 2:size
   xo(io) = ro*xo(io-1)*(1-xo(io-1));
end

%sequence is chaotic where 3.57 < r < 4.
rc = 3.9+((mod((sc(13)+sc(14)+sc(15)+sc(16)+sc(17)+sc(18)+sc(19)+sc(20)+sc(21)+sc(22)+sc(23)+sc(24)),256)/(2^9))*0.1); % r parameter for chaotic regime
size = m*n; % size of chaotic array
xc(1) = 0.2+((mod((sc(1)+sc(2)+sc(3)+sc(4)+sc(5)+sc(6)+sc(7)+sc(8)+sc(9)+sc(10)+sc(11)+sc(12)),256)/(2^9))*0.1); % initial value
for ic = 2:size
   xc(ic) = rc*xc(ic-1)*(1-xc(ic-1));
end

%% Sorting of chaotic sequence

[YO,IO] = sort(xo);

[YC,IC] = sort(xc);

%% Permutation of image

B1 = reshape(img1,1,[]);
Bperm1 = B1(IO);
P1 = reshape(Bperm1,m,n);

B2 = reshape(img2,1,[]);
Bperm2 = B2(IC);
P2 = reshape(Bperm2,m,n);

%% Diffusion of image

for jo = 25:32
    to(jo) = mod(so(jo),256);
end

vo = de2bi(to,8,'left-msb');
lo = vo(:,1);
wo = lo';
uo = bi2de(wo,'left-msb');

d1 = reshape(P1,1,[]);
c1(1) = bitxor(d1(1),uo);
for io = 2:size
    c1(io) = bitxor(d1(io),c1(io-1));
end
C1 = reshape(c1,m,n);
imwrite(C1,'cipher1.tiff');

for jc = 25:32
    tc(jc) = mod(sc(jc),256);
end

vc = de2bi(tc,8,'left-msb');
lc = vc(:,1);
wc = lc';
uc = bi2de(wc,'left-msb');

d2 = reshape(P2,1,[]);
c2(1) = bitxor(d2(1),uc);
for ic = 2:size
    c2(ic) = bitxor(d2(ic),c2(ic-1));
end
C2 = reshape(c2,m,n);
imwrite(C2,'cipher2.tiff');

%% Calculation of npcr and uaci

C1 = imread('D:\dissertation\matlab implementation\comparision 1-d\npcruaci\cipher1.tiff');
C2 = imread('D:\dissertation\matlab implementation\comparision 1-d\npcruaci\cipher2.tiff');

C1 = double(C1);
C2 = double(C2);

sigma1 = 0;
sigma2 = 0;

for y = 1:m
    for z = 1:n
        
        sigma1 = sigma1+(abs(C1(y,z)-C2(y,z)));
        
         if(C1(y,z)==C2(y,z))
            D(y,z) = 0;
        else
            D(y,z) = 1;
         end
        
       sigma2 = sigma2+D(y,z); 
       
    end
end

uaci(f) = (sigma1*100)/(255*size);
npcr(f) = (sigma2*100)/(size);
 
end

uaci = sort(uaci);
npcr = sort(npcr);
 
uacimin = uaci(1)
uacimax = uaci(50)
 
npcrmin = npcr(1)
npcrmax = npcr(50)

npcravg = mean(npcr)
uaciavg = mean(uaci)
        