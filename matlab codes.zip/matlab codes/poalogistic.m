%% Reading of image

clc;
clear;
close all;
img = imread('D:\dissertation\misc\4.2.04.tiff');
img = rgb2gray(img);
[m,n] = size(img);

%% Generation of key

Opta = struct('Method','SHA-256','hex','array');
imhx = DataHash(img,Opta);

j = 1;
for h = 1:2:64
    s(j) = hex2dec(imhx(h:h+1));
    j = j+1;
end

%% Generation of chaotic sequence

%sequence is chaotic where 3.57 < r < 4.
r = 3.9+((mod((s(13)+s(14)+s(15)+s(16)+s(17)+s(18)+s(19)+s(20)+s(21)+s(22)+s(23)+s(24)),256)/(2^9))*0.1); % r parameter for chaotic regime
size = m*n; % size of chaotic array
x(1) = 0.2+((mod((s(1)+s(2)+s(3)+s(4)+s(5)+s(6)+s(7)+s(8)+s(9)+s(10)+s(11)+s(12)),256)/(2^9))*0.1); % initial value
for i = 2:size
   x(i) = r*x(i-1)*(1-x(i-1));
end

%% Sorting of chaotic sequence

[Y,I] = sort(x);

%% Permutation of image

B = reshape(img,1,[]);
Bperm = B(I);
P = reshape(Bperm,m,n);

%% Diffusion of image

for j = 25:32
    t(j) = mod(s(j),256);
end

v = de2bi(t,8,'left-msb');
l = v(:,1);
w = l';
u = bi2de(w,'left-msb');

d = reshape(P,1,[]);
c(1) = bitxor(d(1),u);
for i = 2:size
    c(i) = bitxor(d(i),c(i-1));
end
C = reshape(c,m,n);

%% Occlusion attack on encrypted image

cr = imcrop(C,[0 0 m/2 n/2]);
for ro = 1:m
    for co = 1:n
        if(ro<=m/2 && co<=n/2)
            OC(ro,co) = C(ro,co)-cr(ro,co);
        else
            OC(ro,co) = C(ro,co);
        end
    end
end
imwrite(OC,'pelogistic_lena.tiff');

%% Reverse diffusion of encrypted image

rc = reshape(OC,1,[]);
rd(1) = bitxor(rc(1),u);
for i = 2:size
    rd(i) = bitxor(rc(i),rc(i-1));
end
RP = reshape(rd,m,n);

%% Reverse permutation of encrypted image

RBperm = reshape(RP,1,[]);
RB(I) = RBperm;
imgd = reshape(RB,m,n);
imshow(imgd);
imwrite(imgd,'pdlogistic_lena.tiff');