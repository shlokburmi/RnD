clc;
clear;
close all;

d(1) = 3287280091;
d(2) = 1147300610;
d(3) = 2044886154;
d(4) = 2027892972;
d(5) = 1902027934;
d(6) = 3347438090;
d(7) = 3763270186;
d(8) = 3854829911;

% B = imread('D:\dissertation\matlab implementation\5.1.12.png');
B = imread('cameraman.tif');
[rows, columns] = size(B);

Key = ['0101101111000001000000000111010000010101000100011011000001001100010110001110111100010011001000010000100110111001110001101101100011001000100111010001001101010101101010100111101101111110111010101011111110110101101111101110000110101001100101110000110101010110'];

K = reshape(Key,32,8);

T = bin2dec(K');

RK = zeros(6,32);

for i=0:31
    T(mod(6*i,8)+1)  =  bin2dec(circshift(dec2bin(mod(T(mod(6*i,8)+1)+bin2dec(circshift(dec2bin(d(mod(i,8)+1),32)',-i)'),2^32),32)',-1)');
    T(mod(6*i+1,8)+1) = bin2dec(circshift(dec2bin(mod(T(mod(6*i+1,8)+1)+bin2dec(circshift(dec2bin(d(mod(i,8)+1),32)',-(i+1))'),2^32),32)',-3)');
    T(mod(6*i+2,8)+1) = bin2dec(circshift(dec2bin(mod(T(mod(6*i+2,8)+1)+bin2dec(circshift(dec2bin(d(mod(i,8)+1),32)',-(i+2))'),2^32),32)',-6)');
    T(mod(6*i+3,8)+1) = bin2dec(circshift(dec2bin(mod(T(mod(6*i+3,8)+1)+bin2dec(circshift(dec2bin(d(mod(i,8)+1),32)',-(i+3))'),2^32),32)',-11)');
    T(mod(6*i+4,8)+1) = bin2dec(circshift(dec2bin(mod(T(mod(6*i+4,8)+1)+bin2dec(circshift(dec2bin(d(mod(i,8)+1),32)',-(i+4))'),2^32),32)',-13)');
    T(mod(6*i+5,8)+1) = bin2dec(circshift(dec2bin(mod(T(mod(6*i+5,8)+1)+bin2dec(circshift(dec2bin(d(mod(i,8)+1),32)',-(i+5))'),2^32),32)',-17)');
    RK(1,i+1) = T(mod(6*i,8)+1); RK(2,i+1) = T(mod(6*i+1,8)+1); RK(3,i+1) = T(mod(6*i+2,8)+1); RK(4,i+1) = T(mod(6*i+3,8)+1); RK(5,i+1) = T(mod(6*i+4,8)+1); RK(6,i+1) = T(mod(6*i+5,8)+1);
end
 
P = cell(1,rows*columns);

t = 1;
for i = 1: rows
    for j = 1: columns
       db = dec2bin(B(i,j),8);
       P{t} = db;
       t = t + 1;
    end
end

t = 1;

for k = 1:16:(rows*columns)
    
X_1(t,:) = P(k:k+3);
X1(t,:) = double(bin2dec(cell2mat(X_1(t,:))));

X_2(t,:) = P(k+4:k+7);
X2(t,:) = double(bin2dec(cell2mat(X_2(t,:))));

X_3(t,:) = P(k+8:k+11);
X3(t,:) = double(bin2dec(cell2mat(X_3(t,:))));

X_4(t,:) = P(k+12:k+15);
X4(t,:) = double(bin2dec(cell2mat(X_4(t,:))));

t = t+1;
end

for t = 1:4096
for i=1:32
    X1(t,i+1) = bin2dec(circshift(dec2bin(mod(bitxor(X1(t,i),RK(1,i))+bitxor(X2(t,i),RK(2,i)),2^32),32)',-9)'); 
    X2(t,i+1) = bin2dec(circshift(dec2bin(mod(bitxor(X2(t,i),RK(3,i))+bitxor(X3(t,i),RK(4,i)),2^32),32)',5)'); 
    X3(t,i+1) = bin2dec(circshift(dec2bin(mod(bitxor(X3(t,i),RK(5,i))+bitxor(X4(t,i),RK(6,i)),2^32),32)',3)');
    X4(t,i+1) = X1(t,i);
end
y(t,:) = [X1(t,33), X2(t,33), X3(t,33), X4(t,33)];
end

img = zeros(256*256,1);
t = 1;
for i= 1:4096
    for j=1:4
        bb = dec2bin(y(i,j),32);
        b1 = bin2dec(bb(1:8));
        b2 = bin2dec(bb(9:16));
        b3 = bin2dec(bb(17:24));
        b4 = bin2dec(bb(25:32));
        img(t) = b1;
        img(t+1) = b2;
        img(t+2) = b3;
        img(t+3) = b4;
    t = t+4;
       
    end
end
img2 = reshape(img,256,256);
img2 = uint8((img2)');
imshow(img2)
imwrite(img2,'A.tiff'); 
%c=rem(5510960357,2^32);