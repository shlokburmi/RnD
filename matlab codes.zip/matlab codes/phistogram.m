clc;
Img = imread('D:\dissertation\matlab implementation\comparision 1-d\encryption\beta_lena.tiff');
imhist(Img)
xlabel({'';'Gray scale values'},'fontsize',20)
ylabel('Distribution','fontsize',20)

